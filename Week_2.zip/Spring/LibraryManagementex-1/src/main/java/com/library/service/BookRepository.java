package com.library.repository;

public class BookRepository {
    // Example method
    public void getBookDetails() {
        System.out.println("Fetching book details...");
    }
}

