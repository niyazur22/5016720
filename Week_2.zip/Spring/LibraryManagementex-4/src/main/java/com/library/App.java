package com.library;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Maven Build Set to java version 1.8" );
    }
}
