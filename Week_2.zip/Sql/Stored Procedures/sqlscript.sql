CREATE TABLE accounts ( 
    account_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    account_type VARCHAR2(20), -- e.g., 'savings', 'checking' 
    balance NUMBER 
);

CREATE TABLE employees ( 
    employee_id NUMBER PRIMARY KEY, 
    department_id NUMBER, 
    name VARCHAR2(100), 
    salary NUMBER 
);

CREATE TABLE customers ( 
    customer_id NUMBER PRIMARY KEY, 
    name VARCHAR2(100), 
    age NUMBER, 
    balance NUMBER 
);

INSERT INTO accounts (account_id, customer_id, account_type, balance) VALUES (1, 101, 'savings', 1000);

INSERT INTO accounts (account_id, customer_id, account_type, balance) VALUES (2, 102, 'savings', 1500);

INSERT INTO accounts (account_id, customer_id, account_type, balance) VALUES (3, 103, 'checking', 2000);

INSERT INTO employees (employee_id, department_id, name, salary) VALUES (1, 10, 'John Doe', 50000);

INSERT INTO employees (employee_id, department_id, name, salary) VALUES (2, 10, 'Jane Smith', 55000);

INSERT INTO employees (employee_id, department_id, name, salary) VALUES (3, 20, 'Jim Brown', 60000);

INSERT INTO customers (customer_id, name, age, balance) VALUES (101, 'Alice', 30, 1000);

INSERT INTO customers (customer_id, name, age, balance) VALUES (102, 'Bob', 40, 1500);

INSERT INTO customers (customer_id, name, age, balance) VALUES (103, 'Charlie', 50, 2000);

COMMIT;

CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS 
BEGIN 
    UPDATE accounts 
    SET balance = balance * 1.01 
    WHERE account_type = 'savings'; 
 
    COMMIT; 
END ProcessMonthlyInterest; 
/

CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus( 
    p_department_id IN NUMBER, 
    p_bonus_percentage IN NUMBER 
) IS 
BEGIN 
    UPDATE employees 
    SET salary = salary * (1 + p_bonus_percentage / 100) 
    WHERE department_id = p_department_id; 
 
    COMMIT; 
END UpdateEmployeeBonus; 
/

CREATE OR REPLACE PROCEDURE TransferFunds( 
    p_from_account_id IN NUMBER, 
    p_to_account_id IN NUMBER, 
    p_amount IN NUMBER 
) IS 
    v_from_balance NUMBER; 
BEGIN 
    -- Check balance of source account 
    SELECT balance INTO v_from_balance FROM accounts WHERE account_id = p_from_account_id; 
 
    IF v_from_balance < p_amount THEN 
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds'); 
    END IF; 
 
    -- Transfer funds 
    UPDATE accounts SET balance = balance - p_amount WHERE account_id = p_from_account_id; 
    UPDATE accounts SET balance = balance + p_amount WHERE account_id = p_to_account_id; 
 
    COMMIT; 
END TransferFunds; 
/

BEGIN 
    ProcessMonthlyInterest; 
END; 
/

SELECT * FROM accounts;

BEGIN 
    UpdateEmployeeBonus(10, 10); -- Applying 10% bonus to department 10 
END; 
/

SELECT * FROM employees;

BEGIN 
    TransferFunds(3, 1, 500); -- Transfer 500 from account 3 to account 1 
END; 
/

SELECT * FROM accounts;

