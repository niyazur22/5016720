CREATE TABLE customers ( 
    customer_id NUMBER PRIMARY KEY, 
    name VARCHAR2(100), 
    age NUMBER, 
    balance NUMBER, 
    is_vip CHAR(1) DEFAULT 'N' 
);

CREATE TABLE loans ( 
    loan_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    interest_rate NUMBER, 
    due_date DATE, 
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) 
);

CREATE TABLE loan_reminders ( 
    reminder_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    message VARCHAR2(255), 
    reminder_date DATE 
);

INSERT INTO customers (customer_id, name, age, balance) 
VALUES (1, 'Ram', 65, 12000);

INSERT INTO customers (customer_id, name, age, balance) 
VALUES (2, 'Shyam', 55, 8000);

INSERT INTO customers (customer_id, name, age, balance) 
VALUES (3, 'Brown', 70, 15000);

INSERT INTO loans (loan_id, customer_id, interest_rate, due_date) 
VALUES (1, 1, 5.0, SYSDATE + 10);

INSERT INTO loans (loan_id, customer_id, interest_rate, due_date) 
VALUES (2, 2, 4.5, SYSDATE + 40);

INSERT INTO loans (loan_id, customer_id, interest_rate, due_date) 
VALUES (3, 3, 6.0, SYSDATE + 5);

BEGIN 
    FOR rec IN (SELECT customer_id FROM customers WHERE age > 60) LOOP 
        UPDATE loans 
        SET interest_rate = interest_rate - 1 
        WHERE customer_id = rec.customer_id; 
    END LOOP; 
END; 
/

BEGIN 
    FOR rec IN (SELECT customer_id FROM customers WHERE balance > 10000) LOOP 
        UPDATE customers 
        SET is_vip = 'Y' 
        WHERE customer_id = rec.customer_id; 
    END LOOP; 
END; 
/

CREATE SEQUENCE loan_reminders_seq 
START WITH 1 
INCREMENT BY 1;

DECLARE 
    v_message VARCHAR2(255); 
BEGIN 
    FOR rec IN (SELECT customer_id, due_date FROM loans WHERE due_date <= SYSDATE + 30) LOOP 
        v_message := 'Dear customer, your loan is due on ' || TO_CHAR(rec.due_date, 'MM-DD-YYYY') || '.'; 
        INSERT INTO loan_reminders (reminder_id, customer_id, message, reminder_date) 
        VALUES (loan_reminders_seq.NEXTVAL, rec.customer_id, v_message, SYSDATE); 
         
        DBMS_OUTPUT.PUT_LINE('Reminder sent to customer ' || rec.customer_id || ': ' || v_message); 
    END LOOP; 
END; 
/

