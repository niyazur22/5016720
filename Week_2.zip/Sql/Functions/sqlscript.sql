CREATE TABLE customers ( 
    customer_id NUMBER PRIMARY KEY, 
    name VARCHAR2(100), 
    date_of_birth DATE, 
    balance NUMBER 
);

CREATE TABLE loans ( 
    loan_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    loan_amount NUMBER, 
    interest_rate NUMBER, 
    loan_duration_years NUMBER 
);

CREATE OR REPLACE FUNCTION CalculateAge(p_date_of_birth DATE) RETURN NUMBER IS 
    v_age NUMBER; 
BEGIN 
    v_age := TRUNC(MONTHS_BETWEEN(SYSDATE, p_date_of_birth) / 12); 
    RETURN v_age; 
END CalculateAge; 
/

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment( 
    p_loan_amount NUMBER, 
    p_interest_rate NUMBER, 
    p_loan_duration_years NUMBER 
) RETURN NUMBER IS 
    v_monthly_installment NUMBER; 
    v_monthly_interest_rate NUMBER; 
    v_total_months NUMBER; 
BEGIN 
    v_monthly_interest_rate := p_interest_rate / 1200; 
    v_total_months := p_loan_duration_years * 12; 
 
    v_monthly_installment := p_loan_amount * v_monthly_interest_rate / 
                             (1 - POWER(1 + v_monthly_interest_rate, -v_total_months)); 
    RETURN v_monthly_installment; 
END CalculateMonthlyInstallment; 
/

CREATE OR REPLACE FUNCTION HasSufficientBalance( 
    p_account_id NUMBER, 
    p_amount NUMBER 
) RETURN BOOLEAN IS 
    v_balance NUMBER; 
BEGIN 
    SELECT balance INTO v_balance FROM customers WHERE customer_id = p_account_id; 
 
    IF v_balance >= p_amount THEN 
        RETURN TRUE; 
    ELSE 
        RETURN FALSE; 
    END IF; 
END HasSufficientBalance; 
/

INSERT INTO customers (customer_id, name, date_of_birth, balance) VALUES (1, 'Alice', DATE '1985-05-15', 5000);

INSERT INTO customers (customer_id, name, date_of_birth, balance) VALUES (2, 'Bob', DATE '1970-09-30', 15000);

INSERT INTO customers (customer_id, name, date_of_birth, balance) VALUES (3, 'Charlie', DATE '1990-12-01', 1000);

INSERT INTO loans (loan_id, customer_id, loan_amount, interest_rate, loan_duration_years) VALUES (1, 1, 10000, 5, 5);

INSERT INTO loans (loan_id, customer_id, loan_amount, interest_rate, loan_duration_years) VALUES (2, 2, 20000, 4.5, 10);

COMMIT;

SELECT CalculateAge(date_of_birth) AS age FROM customers WHERE customer_id = 1;

SELECT customer_id, name, CalculateAge(date_of_birth) AS age FROM customers;

SELECT CalculateMonthlyInstallment(loan_amount, interest_rate, loan_duration_years) AS monthly_installment 
FROM loans WHERE loan_id = 1;

SELECT loan_id, customer_id, CalculateMonthlyInstallment(loan_amount, interest_rate, loan_duration_years) AS monthly_installment 
FROM loans;

SELECT HasSufficientBalance(1, 3000) AS has_sufficient_balance FROM dual;

SELECT customer_id, name, HasSufficientBalance(customer_id, 3000) AS has_sufficient_balance FROM customers;

