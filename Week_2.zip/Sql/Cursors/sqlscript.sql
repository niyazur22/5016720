CREATE TABLE customers ( 
    customer_id NUMBER PRIMARY KEY, 
    name VARCHAR2(100), 
    date_of_birth DATE, 
    balance NUMBER 
);

CREATE TABLE transactions ( 
    transaction_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    transaction_type VARCHAR2(10), -- 'deposit' or 'withdrawal' 
    amount NUMBER, 
    transaction_date DATE 
);

CREATE TABLE loans ( 
    loan_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    loan_amount NUMBER, 
    interest_rate NUMBER, 
    loan_start_date DATE, 
    loan_duration_years NUMBER 
);

INSERT INTO customers (customer_id, name, date_of_birth, balance)  
VALUES (1, 'Alice', DATE '1985-05-15', 5000);

INSERT INTO customers (customer_id, name, date_of_birth, balance)  
VALUES (2, 'Bob', DATE '1970-09-30', 15000);

INSERT INTO customers (customer_id, name, date_of_birth, balance)  
VALUES (3, 'Charlie', DATE '1990-12-01', 1000);

INSERT INTO transactions (transaction_id, customer_id, transaction_type, amount, transaction_date)  
VALUES (1, 1, 'deposit', 1000, ADD_MONTHS(SYSDATE, -1));

INSERT INTO transactions (transaction_id, customer_id, transaction_type, amount, transaction_date)  
VALUES (2, 2, 'withdrawal', 500, SYSDATE);

INSERT INTO transactions (transaction_id, customer_id, transaction_type, amount, transaction_date)  
VALUES (3, 3, 'deposit', 2000, SYSDATE);

INSERT INTO loans (loan_id, customer_id, loan_amount, interest_rate, loan_start_date, loan_duration_years)  
VALUES (1, 1, 10000, 5.0, DATE '2020-01-01', 5);

INSERT INTO loans (loan_id, customer_id, loan_amount, interest_rate, loan_start_date, loan_duration_years)  
VALUES (2, 2, 20000, 6.0, DATE '2019-07-01', 10);

INSERT INTO loans (loan_id, customer_id, loan_amount, interest_rate, loan_start_date, loan_duration_years)  
VALUES (3, 3, 15000, 4.5, DATE '2021-05-01', 7);

COMMIT;

DECLARE 
    CURSOR cur_monthly_statements IS 
        SELECT c.customer_id, c.name, t.transaction_type, t.amount, t.transaction_date 
        FROM customers c 
        JOIN transactions t ON c.customer_id = t.customer_id 
        WHERE TRUNC(t.transaction_date, 'MM') = TRUNC(SYSDATE, 'MM'); 
 
    v_customer_id customers.customer_id%TYPE; 
    v_name customers.name%TYPE; 
    v_transaction_type transactions.transaction_type%TYPE; 
    v_amount transactions.amount%TYPE; 
    v_transaction_date transactions.transaction_date%TYPE; 
BEGIN 
    OPEN cur_monthly_statements; 
    LOOP 
        FETCH cur_monthly_statements INTO v_customer_id, v_name, v_transaction_type, v_amount, v_transaction_date; 
        EXIT WHEN cur_monthly_statements%NOTFOUND; 
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id || ', Name: ' || v_name || ', Transaction: ' || v_transaction_type || ', Amount: ' || v_amount || ', Date: ' || v_transaction_date); 
    END LOOP; 
    CLOSE cur_monthly_statements; 
END; 
/

DECLARE 
    CURSOR cur_apply_annual_fee IS 
        SELECT customer_id, balance 
        FROM customers; 
 
    v_customer_id customers.customer_id%TYPE; 
    v_balance customers.balance%TYPE; 
    v_annual_fee CONSTANT NUMBER := 100;  -- Example annual fee 
BEGIN 
    OPEN cur_apply_annual_fee; 
    LOOP 
        FETCH cur_apply_annual_fee INTO v_customer_id, v_balance; 
        EXIT WHEN cur_apply_annual_fee%NOTFOUND; 
 
        -- Deduct annual fee from balance 
        v_balance := v_balance - v_annual_fee; 
 
        -- Update the customer's balance 
        UPDATE customers 
        SET balance = v_balance 
        WHERE customer_id = v_customer_id; 
 
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id || ', New Balance: ' || v_balance); 
    END LOOP; 
    CLOSE cur_apply_annual_fee; 
 
    COMMIT; 
END; 
/

DECLARE 
    CURSOR cur_update_loan_interest IS 
        SELECT loan_id, interest_rate 
        FROM loans; 
 
    v_loan_id loans.loan_id%TYPE; 
    v_interest_rate loans.interest_rate%TYPE; 
BEGIN 
    OPEN cur_update_loan_interest; 
    LOOP 
        FETCH cur_update_loan_interest INTO v_loan_id, v_interest_rate; 
        EXIT WHEN cur_update_loan_interest%NOTFOUND; 
 
        -- Example new policy: Increase interest rate by 0.5% 
        v_interest_rate := v_interest_rate + 0.5; 
 
        -- Update the loan's interest rate 
        UPDATE loans 
        SET interest_rate = v_interest_rate 
        WHERE loan_id = v_loan_id; 
 
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || v_loan_id || ', New Interest Rate: ' || v_interest_rate); 
    END LOOP; 
    CLOSE cur_update_loan_interest; 
 
    COMMIT; 
END; 
/

