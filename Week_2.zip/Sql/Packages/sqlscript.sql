CREATE TABLE customers ( 
    customer_id NUMBER PRIMARY KEY, 
    name VARCHAR2(100), 
    date_of_birth DATE, 
    balance NUMBER 
);

CREATE TABLE employees ( 
    employee_id NUMBER PRIMARY KEY, 
    name VARCHAR2(100), 
    date_of_birth DATE, 
    hire_date DATE, 
    salary NUMBER 
);

CREATE TABLE accounts ( 
    account_id NUMBER PRIMARY KEY, 
    customer_id NUMBER, 
    balance NUMBER, 
    account_type VARCHAR2(20) -- 'savings' or 'checking' 
);

INSERT INTO customers (customer_id, name, date_of_birth, balance)  
VALUES (1, 'Alice', DATE '1985-05-15', 5000);

INSERT INTO customers (customer_id, name, date_of_birth, balance)  
VALUES (2, 'Bob', DATE '1970-09-30', 15000);

INSERT INTO customers (customer_id, name, date_of_birth, balance)  
VALUES (3, 'Charlie', DATE '1990-12-01', 1000);

INSERT INTO employees (employee_id, name, date_of_birth, hire_date, salary)  
VALUES (1, 'David', DATE '1980-03-10', DATE '2020-01-15', 60000);

INSERT INTO employees (employee_id, name, date_of_birth, hire_date, salary)  
VALUES (2, 'Eva', DATE '1992-07-25', DATE '2021-06-20', 50000);

INSERT INTO employees (employee_id, name, date_of_birth, hire_date, salary)  
VALUES (3, 'Frank', DATE '1985-11-30', DATE '2019-11-01', 55000);

INSERT INTO accounts (account_id, customer_id, balance, account_type)  
VALUES (1, 1, 3000, 'savings');

INSERT INTO accounts (account_id, customer_id, balance, account_type)  
VALUES (2, 1, 2000, 'checking');

INSERT INTO accounts (account_id, customer_id, balance, account_type)  
VALUES (3, 2, 15000, 'savings');

INSERT INTO accounts (account_id, customer_id, balance, account_type)  
VALUES (4, 3, 1000, 'checking');

COMMIT;

CREATE OR REPLACE PACKAGE CustomerManagement AS 
    PROCEDURE AddCustomer(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_balance NUMBER); 
    PROCEDURE UpdateCustomerDetails(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_balance NUMBER); 
    FUNCTION GetCustomerBalance(p_customer_id NUMBER) RETURN NUMBER; 
END CustomerManagement; 
/

CREATE OR REPLACE PACKAGE BODY CustomerManagement AS 
    PROCEDURE AddCustomer(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_balance NUMBER) IS 
    BEGIN 
        INSERT INTO customers (customer_id, name, date_of_birth, balance) 
        VALUES (p_customer_id, p_name, p_date_of_birth, p_balance); 
    END AddCustomer; 
 
    PROCEDURE UpdateCustomerDetails(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_balance NUMBER) IS 
    BEGIN 
        UPDATE customers 
        SET name = p_name, date_of_birth = p_date_of_birth, balance = p_balance 
        WHERE customer_id = p_customer_id; 
    END UpdateCustomerDetails; 
 
    FUNCTION GetCustomerBalance(p_customer_id NUMBER) RETURN NUMBER IS 
        v_balance NUMBER; 
    BEGIN 
        SELECT balance INTO v_balance FROM customers WHERE customer_id = p_customer_id; 
        RETURN v_balance; 
    END GetCustomerBalance; 
END CustomerManagement; 
/

CREATE OR REPLACE PACKAGE EmployeeManagement AS 
    PROCEDURE HireEmployee(p_employee_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_hire_date DATE, p_salary NUMBER); 
    PROCEDURE UpdateEmployeeDetails(p_employee_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_salary NUMBER); 
    FUNCTION CalculateAnnualSalary(p_employee_id NUMBER) RETURN NUMBER; 
END EmployeeManagement; 
/

CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS 
    PROCEDURE HireEmployee(p_employee_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_hire_date DATE, p_salary NUMBER) IS 
    BEGIN 
        INSERT INTO employees (employee_id, name, date_of_birth, hire_date, salary) 
        VALUES (p_employee_id, p_name, p_date_of_birth, p_hire_date, p_salary); 
    END HireEmployee; 
 
    PROCEDURE UpdateEmployeeDetails(p_employee_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE, p_salary NUMBER) IS 
    BEGIN 
        UPDATE employees 
        SET name = p_name, date_of_birth = p_date_of_birth, salary = p_salary 
        WHERE employee_id = p_employee_id; 
    END UpdateEmployeeDetails; 
 
    FUNCTION CalculateAnnualSalary(p_employee_id NUMBER) RETURN NUMBER IS 
        v_salary NUMBER; 
    BEGIN 
        SELECT salary INTO v_salary FROM employees WHERE employee_id = p_employee_id; 
        RETURN v_salary * 12; -- Assuming monthly salary 
    END CalculateAnnualSalary; 
END EmployeeManagement; 
/

CREATE OR REPLACE PACKAGE AccountOperations AS 
    PROCEDURE OpenAccount(p_account_id NUMBER, p_customer_id NUMBER, p_balance NUMBER, p_account_type VARCHAR2); 
    PROCEDURE CloseAccount(p_account_id NUMBER); 
    FUNCTION GetTotalBalance(p_customer_id NUMBER) RETURN NUMBER; 
END AccountOperations; 
/

CREATE OR REPLACE PACKAGE BODY AccountOperations AS 
    PROCEDURE OpenAccount(p_account_id NUMBER, p_customer_id NUMBER, p_balance NUMBER, p_account_type VARCHAR2) IS 
    BEGIN 
        INSERT INTO accounts (account_id, customer_id, balance, account_type) 
        VALUES (p_account_id, p_customer_id, p_balance, p_account_type); 
    END OpenAccount; 
 
    PROCEDURE CloseAccount(p_account_id NUMBER) IS 
    BEGIN 
        DELETE FROM accounts WHERE account_id = p_account_id; 
    END CloseAccount; 
 
    FUNCTION GetTotalBalance(p_customer_id NUMBER) RETURN NUMBER IS 
        v_total_balance NUMBER; 
    BEGIN 
        SELECT SUM(balance) INTO v_total_balance FROM accounts WHERE customer_id = p_customer_id; 
        RETURN v_total_balance; 
    END GetTotalBalance; 
END AccountOperations; 
/

BEGIN 
    CustomerManagement.AddCustomer(4, 'Diana', DATE '1995-08-25', 2000); 
    CustomerManagement.UpdateCustomerDetails(4, 'Diana Prince', DATE '1995-08-25', 2500); 
    DBMS_OUTPUT.PUT_LINE('Customer Balance: ' || CustomerManagement.GetCustomerBalance(4)); 
END; 
/

BEGIN 
    EmployeeManagement.HireEmployee(4, 'George', DATE '1987-02-14', DATE '2022-01-01', 70000); 
    EmployeeManagement.UpdateEmployeeDetails(4, 'George Smith', DATE '1987-02-14', 72000); 
    DBMS_OUTPUT.PUT_LINE('Annual Salary: ' || EmployeeManagement.CalculateAnnualSalary(4)); 
END; 
/

BEGIN 
    AccountOperations.OpenAccount(5, 2, 5000, 'savings'); 
    AccountOperations.CloseAccount(5); 
    DBMS_OUTPUT.PUT_LINE('Total Balance: ' || AccountOperations.GetTotalBalance(2)); 
END; 
/

