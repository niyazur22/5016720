public class DecoratorPatternTest {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        // Sending notification via Email, SMS, and Slack
        slackNotifier.send("Your order has been shipped!");

        // Sending notification via Email and SMS only
        smsNotifier.send("Your package is out for delivery!");

        // Sending notification via Email only
        emailNotifier.send("Your package has been delivered!");
    }
}
