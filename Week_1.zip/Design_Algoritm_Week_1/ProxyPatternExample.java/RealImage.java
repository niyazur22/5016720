public class RealImage implements Image {
    private String imageURL;

    public RealImage(String imageURL) {
        this.imageURL = imageURL;
        loadImageFromRemoteServer();
    }
    private void loadImageFromRemoteServer() {
        System.out.println("Loading image from " + imageURL);
        try {
            Thread.sleep(2000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Image loaded from " + imageURL);
    }
    @Override
    public void display() {
        System.out.println("Displaying image from " + imageURL);
    }
}

