public class BuilderPatternTest {
        public static void main(String[] args) {
            Computer gamingComputer = new Computer.Builder()
                    .setCPU("Intel Core i9")
                    .setRAM("32GB")
                    .setStorage("2TB SSD")
                    .setGPU("NVIDIA RTX 3090")
                    .setMotherboard("ASUS ROG Maximus XIII")
                    .setPowerSupply("850W")
                    .setCoolingSystem("Liquid Cooling")
                    .build();
            System.out.println(gamingComputer);
    
            Computer officeComputer = new Computer.Builder()
                    .setCPU("Intel Core i5")
                    .setRAM("8GB")
                    .setStorage("500GB HDD")
                    .setMotherboard("Gigabyte B450M")
                    .setPowerSupply("450W")
                    .build();
            System.out.println(officeComputer);
            Computer multimediaComputer = new Computer.Builder()
                    .setCPU("AMD Ryzen 7")
                    .setRAM("16GB")
                    .setStorage("1TB SSD")
                    .setGPU("NVIDIA GTX 1660")
                    .setMotherboard("MSI B450 TOMAHAWK")
                    .setPowerSupply("650W")
                    .setCoolingSystem("Air Cooling")
                    .build();
            System.out.println(multimediaComputer);
        }
    }
    