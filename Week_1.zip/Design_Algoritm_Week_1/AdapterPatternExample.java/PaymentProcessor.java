package AdapterPatternExample.java;
package AdapterPatternExample.java;
public interface PaymentProcessor {
    void processPayment(double amount);
}

