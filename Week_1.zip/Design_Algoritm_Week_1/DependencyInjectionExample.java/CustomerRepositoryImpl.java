public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
        if (id == 1) {
            return new Customer(1, "John Doe");
        } else {
            return null;
        }
    }
}
